// Husen Hisab Customer Demo - local-first, no login/OTP
const CONTACT_WHATSAPP = "918980056239"; // Husen Hisab સંપર્ક નંબર (+91)
const KEY = "husen_customer_demo_v1";
const TRIAL_KEY = "husen_customer_demo_trial_start";
const $ = id => document.getElementById(id);
const money = n => "₹" + (Number(n)||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const today = () => new Date().toLocaleDateString("en-CA");
const dateText = d => new Date(d+"T00:00:00").toLocaleDateString("gu-IN",{day:"2-digit",month:"short",year:"numeric"});
let db = JSON.parse(localStorage.getItem(KEY) || '{"shop":"મારી દુકાન","shopPhone":"","bills":[],"expenses":[]}');
if (!localStorage.getItem(TRIAL_KEY)) localStorage.setItem(TRIAL_KEY,String(Date.now()));
const trialStart = Number(localStorage.getItem(TRIAL_KEY));
const trialEnd = trialStart + 24*60*60*1000;
let selectedBill = null;
function save(){localStorage.setItem(KEY,JSON.stringify(db));render()}
function isExpired(){return Date.now()>=trialEnd}
function ensureTrial(){
 if(isExpired()){
   document.querySelector("main").innerHTML=`<section class="page active" style="text-align:center;padding:30px 8px"><div style="font-size:55px">⏳</div><h2>તમારો 1 દિવસનો Demo પૂરો થયો</h2><p class="muted">Husen Hisab ચાલુ રાખવા માટે અમારી સાથે WhatsApp પર સંપર્ક કરો.</p><button class="primary" id="contactNow">WhatsApp પર સંપર્ક કરો</button></section>`;
   document.querySelector(".bottom").style.display="none";
   $("contactNow").onclick=()=>openWhatsApp(CONTACT_WHATSAPP,"નમસ્તે, મારે Husen Hisab એપ ખરીદવી છે.");
   $("trialBanner").textContent="Demo સમય પૂર્ણ";
   return true;
 }
 const left=trialEnd-Date.now(), hours=Math.floor(left/3600000), mins=Math.floor((left%3600000)/60000);
 $("trialBanner").textContent=`મફત Demo ચાલુ છે • બાકી સમય: ${hours} કલાક ${mins} મિનિટ`;
 return false;
}
function openWhatsApp(phone,msg){
 const clean=(phone||"").replace(/\D/g,"");
 const url="https://wa.me/"+clean+"?text="+encodeURIComponent(msg);
 window.open(url,"_blank");
}
function shareBill(b){
 const msg=`${db.shop}\nબિલ નંબર: ${b.id}\nતારીખ: ${dateText(b.date)}\nગ્રાહક: ${b.customer}\nવિગત: ${b.details}\nકુલ બિલ: ${money(b.amount)}\nમળ્યા: ${money(b.paid)} (${b.method==="cash"?"Cash":b.method==="bank"?"Bank / UPI":"બાકી"})\nબાકી: ${money(b.amount-b.paid)}\nઆભાર!`;
 if(b.phone) openWhatsApp(b.phone,msg); else if(navigator.share) navigator.share({title:"બિલ",text:msg}).catch(()=>{}); else alert(msg);
}
function reminder(b){
 const msg=`નમસ્તે ${b.customer}, ${db.shop} તરફથી યાદ અપાવીએ છીએ કે તમારા બિલ નંબર ${b.id} માં ${money(b.amount-b.paid)} બાકી છે. કૃપા કરીને અનુકૂળ સમયે ચુકવણી કરશો. આભાર.`;
 if(b.phone) openWhatsApp(b.phone,msg); else alert("આ ગ્રાહકનો મોબાઇલ નંબર નોંધેલો નથી.");
}
function showModal(html){$("modalContent").innerHTML=html;$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden")}
$("modalClose").onclick=closeModal;
function go(page){
 if(ensureTrial())return;
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 $(page).classList.add("active");
 document.querySelectorAll(".navbtn").forEach(b=>b.classList.toggle("selected",b.dataset.go===page));
 render();
}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("shopEdit").onclick=()=>go("settings");
$("todayDate").textContent=dateText(today());
$("shopForm").onsubmit=e=>{e.preventDefault();db.shop=$("shopNameInput").value.trim()||"મારી દુકાન";db.shopPhone=$("shopPhoneInput").value.trim();save();go("dashboard");};
$("billForm").onsubmit=e=>{
 e.preventDefault();
 const amount=Number($("billAmount").value), paid=Number($("billPaid").value);
 if(amount<=0||paid<0||paid>amount){alert("રકમ યોગ્ય નાખો. મળેલી રકમ કુલ બિલ કરતાં વધુ ન હોવી જોઈએ.");return;}
 const method=paid===0?"credit":$("billMethod").value;
 const b={id:"HH"+Date.now().toString().slice(-7),date:today(),customer:$("billCustomer").value.trim(),phone:$("billPhone").value.trim(),details:$("billDetails").value.trim(),amount,paid,method};
 db.bills.unshift(b);save();e.target.reset();$("billPaid").value="0";
 showModal(`<h3>બિલ સાચવાઈ ગયું ✓</h3><p>${b.customer} • ${money(b.amount)}</p><div class="actions"><button id="shareNew">WhatsApp બિલ મોકલો</button><button id="doneNew">થઈ ગયું</button></div>`);
 $("shareNew").onclick=()=>shareBill(b);$("doneNew").onclick=()=>{closeModal();go("bills")};
};
$("expenseForm").onsubmit=e=>{e.preventDefault();const amount=Number($("expenseAmount").value);if(amount<=0)return;db.expenses.unshift({id:Date.now(),date:today(),name:$("expenseName").value.trim(),amount});save();e.target.reset();};
$("billSearch").oninput=renderBills;
$("exportData").onclick=()=>{const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="husen-hisab-backup.json";a.click();URL.revokeObjectURL(a.href)};
function billHtml(b){
 const due=b.amount-b.paid;
 return `<div class="item"><div><b>${esc(b.customer)}</b><small>${dateText(b.date)} • ${esc(b.details)} • #${b.id}</small><small>મળ્યા ${money(b.paid)} • ${due>0?"બાકી "+money(due):"ચૂકવાઈ ગયું"}</small></div><div class="amount ${due>0?"due":"paid"}">${money(b.amount)}<div class="actions"><button data-view="${b.id}">જુઓ</button></div></div></div>`;
}
function esc(s){return String(s||"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderBills(){
 const q=($("billSearch")?.value||"").toLowerCase();
 const arr=db.bills.filter(b=>b.customer.toLowerCase().includes(q)||b.id.toLowerCase().includes(q));
 $("allBills").innerHTML=arr.length?arr.map(billHtml).join(""):'<div class="empty">હજુ કોઈ બિલ બનાવ્યું નથી.</div>';
 document.querySelectorAll("[data-view]").forEach(btn=>btn.onclick=()=>viewBill(btn.dataset.view));
}
function viewBill(id){
 const b=db.bills.find(x=>x.id===id);if(!b)return;const due=b.amount-b.paid;
 showModal(`<h3>બિલ #${b.id}</h3><p><b>${esc(b.customer)}</b><br>${esc(b.details)}<br>${dateText(b.date)}</p><hr><p>કુલ બિલ: <b>${money(b.amount)}</b><br>મળ્યા: ${money(b.paid)}<br>બાકી: <b class="${due>0?"due":"paid"}">${money(due)}</b></p><div class="actions"><button id="billShare">WhatsApp બિલ</button>${due>0?'<button id="billRemind">બાકી યાદ અપાવો</button><button id="billPay">ચુકવણી નોંધો</button>':''}</div>`);
 $("billShare").onclick=()=>shareBill(b);
 if(due>0){$("billRemind").onclick=()=>reminder(b);$("billPay").onclick=()=>{showModal(`<h3>ચુકવણી નોંધો</h3><p>બાકી: ${money(due)}</p><label>હવે મળેલી રકમ<input id="payAmount" type="number" min="1" max="${due}" value="${due}"></label><label>માધ્યમ<select id="payMethod"><option value="cash">Cash</option><option value="bank">Bank / UPI</option></select></label><button class="primary" id="savePay">ચુકવણી સાચવો</button>`);$("savePay").onclick=()=>{const v=Number($("payAmount").value);if(v<=0||v>due){alert("યોગ્ય રકમ નાખો");return;}b.paid+=v;b.method=$("payMethod").value;save();viewBill(id)};};}
}
function renderCustomers(){
 const map={};db.bills.forEach(b=>{if(!map[b.customer])map[b.customer]={name:b.customer,phone:b.phone,due:0,count:0};map[b.customer].due+=b.amount-b.paid;map[b.customer].count++});
 const arr=Object.values(map).filter(x=>x.due>0);
 $("customerList").innerHTML=arr.length?arr.map(c=>`<div class="item"><div><b>${esc(c.name)}</b><small>${c.count} બિલ • ${esc(c.phone||"નંબર નથી")}</small></div><div class="amount due">${money(c.due)}</div></div>`).join(""):'<div class="empty">કોઈ બાકી રકમ નથી.</div>';
}
function render(){
 if(ensureTrial())return;
 $("shopTitle").textContent=db.shop||"મારી દુકાન";$("shopNameInput").value=db.shop||"";$("shopPhoneInput").value=db.shopPhone||"";
 const todays=db.bills.filter(b=>b.date===today());
 const cash=todays.filter(b=>b.method==="cash").reduce((s,b)=>s+b.paid,0);
 const bank=todays.filter(b=>b.method==="bank").reduce((s,b)=>s+b.paid,0);
 const received=todays.reduce((s,b)=>s+b.paid,0);
 const due=db.bills.reduce((s,b)=>s+b.amount-b.paid,0);
 $("todayReceived").textContent=money(received);$("cashTotal").textContent=money(cash);$("bankTotal").textContent=money(bank);$("dueTotal").textContent=money(due);$("billCount").textContent=todays.length;
 $("recentBills").innerHTML=db.bills.length?db.bills.slice(0,4).map(billHtml).join(""):'<div class="empty">તમારું પહેલું બિલ બનાવો.</div>';
 $("rCash").textContent=money(cash);$("rBank").textContent=money(bank);$("rIncome").textContent=money(received);
 const exp=db.expenses.filter(x=>x.date===today()).reduce((s,x)=>s+x.amount,0);
 $("rExpense").textContent=money(exp);$("rNet").textContent=money(received-exp);
 $("expenseList").innerHTML=db.expenses.filter(x=>x.date===today()).map(x=>`<div class="item"><div><b>${esc(x.name)}</b><small>${dateText(x.date)}</small></div><b class="due">${money(x.amount)}</b></div>`).join("")||'<div class="empty">આજે ખર્ચ નોંધ્યો નથી.</div>';
 renderBills();renderCustomers();
}
if(!ensureTrial())render();
