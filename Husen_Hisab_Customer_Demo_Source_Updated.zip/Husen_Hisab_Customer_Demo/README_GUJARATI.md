# Husen Hisab Customer Demo APK

આ એક અલગ Android Customer Demo project છે. App માં Login/OTP નથી.

## ફીચર્સ
- દુકાનનું નામ સેટ કરો
- 24 કલાકનું પ્રથમ ઉપયોગથી Demo
- બિલ બનાવો: Cash / Bank / બાકી
- ગ્રાહક અને બિલની યાદી
- બાકી વસૂલાત નોંધો
- WhatsApp પર બિલ અને બાકી રકમની યાદ અપાવો
- રોજની આવક અને ખર્ચ
- Demo પૂરો થયા પછી WhatsApp Contact બટન

## APK બનાવવાની રીત (GitHub)
1. GitHub પર નવી repository બનાવો.
2. આ ZIP extract કરીને તેની અંદરની બધી files repository ના `main` branch માં upload કરો.
3. GitHub માં **Actions** ખોલો.
4. `Build Husen Hisab Customer Demo APK` workflow પસંદ કરો.
5. **Run workflow** દબાવો (અથવા main પર upload પછી આપમેળે build થશે).
6. Build પૂરો થયા પછી workflow run માંથી **Artifacts** માં `Husen-Hisab-Customer-Demo-APK` download કરો.
7. ZIP ખોલો; તેમાં `app-debug.apk` મળશે.

## ખાસ નોંધ
24 કલાકનો સમય આ demo આવૃત્તિમાં આ ફોનના app storage માં સાચવાય છે. App data clear કરવાથી અથવા app ફરી install કરવાથી trial ફરી શરૂ થઈ શકે છે. દરેક ગ્રાહક માટે ખરેખર એક જ વાર 48 કલાકનું નિયંત્રણ જરૂરી હોય તો પછી online license/server જોડવું પડશે. WhatsApp message share sheet ખોલે છે; ગ્રાહક પોતે Send દબાવે છે.

## WhatsApp Contact
`www/app.js` માં WhatsApp સંપર્ક નંબર પહેલેથી જ `918980056239` સેટ છે.
