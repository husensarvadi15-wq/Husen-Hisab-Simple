package com.husen.stockmanager;

import android.app.*;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    DB db; LinearLayout page, list; TextView summary;
    int blue = 0xFF145DA0;
    String money(double n){ return "₹" + String.format(Locale.getDefault(),"%.2f",n); }
    public void onCreate(Bundle b){ super.onCreate(b); db=new DB(this); showHome(); }
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF17212B); t.setPadding(8,8,8,8); return t; }
    Button btn(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setOnClickListener(v->r.run()); return b; }
    EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); return e; }
    void base(String title){
        ScrollView sc=new ScrollView(this); page=new LinearLayout(this); page.setOrientation(1); page.setPadding(16,16,16,24);
        sc.addView(page); setContentView(sc);
        TextView h=text(title,24); h.setTypeface(null,Typeface.BOLD); h.setTextColor(blue); page.addView(h);
    }
    void showHome(){
        base("Husen Stock Manager");
        page.addView(text("દુકાનના સ્ટોકનો સંપૂર્ણ હિસાબ",16));
        summary=text("",18); summary.setTypeface(null,Typeface.BOLD); page.addView(summary); refreshSummary();
        page.addView(btn("＋ નવી વસ્તુ ઉમેરો",()->addProduct()));
        page.addView(btn("📦 સ્ટોક યાદી",()->showProducts()));
        page.addView(btn("🛒 ખરીદી નોંધો",()->chooseProduct("ખરીદી",true)));
        page.addView(btn("💰 વેચાણ નોંધો",()->chooseProduct("વેચાણ",false)));
        page.addView(btn("📊 નફા અને રિપોર્ટ",()->showReport()));
        page.addView(text("તમારો ડેટા આ ફોનમાં જ સાચવાય છે. ઇન્ટરનેટની જરૂર નથી.",13));
    }
    void refreshSummary(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*), COALESCE(SUM(qty*cost),0), COALESCE(SUM(qty),0) FROM products",null);
        if(c.moveToFirst()) summary.setText("કુલ વસ્તુઓ: "+c.getInt(0)+"\nહાલના સ્ટોકની પડતર કિંમત: "+money(c.getDouble(1))+"\nકુલ જથ્થો: "+c.getDouble(2));
        c.close();
    }
    void addProduct(){
        base("નવી વસ્તુ ઉમેરો");
        EditText name=field("વસ્તુનું નામ"); EditText cost=field("ખરીદ કિંમત (₹)"); cost.setInputType(8194);
        EditText price=field("વેચાણ કિંમત (₹)"); price.setInputType(8194);
        EditText qty=field("શરૂઆતનો જથ્થો"); qty.setInputType(8194);
        page.addView(name);page.addView(cost);page.addView(price);page.addView(qty);
        page.addView(btn("સેવ કરો",()->{
            try{ if(name.getText().toString().trim().isEmpty()) throw new Exception();
                db.add(name.getText().toString().trim(),Double.parseDouble(cost.getText().toString()),Double.parseDouble(price.getText().toString()),Double.parseDouble(qty.getText().toString()));
                showHome(); Toast.makeText(this,"વસ્તુ સેવ થઈ ગઈ",0).show();
            }catch(Exception ex){Toast.makeText(this,"બધી વિગતો સાચી રીતે भरो",0).show();}
        }));
        page.addView(btn("પાછા જાઓ",()->showHome()));
    }
    void showProducts(){
        base("સ્ટોક યાદી");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,cost,price,qty FROM products ORDER BY name",null);
        if(c.getCount()==0) page.addView(text("હજુ કોઈ વસ્તુ ઉમેરેલી નથી.",16));
        while(c.moveToNext()){
            int id=c.getInt(0); String n=c.getString(1); double co=c.getDouble(2),pr=c.getDouble(3),q=c.getDouble(4);
            TextView row=text(n+"\nજથ્થો: "+q+"   પડતર: "+money(co)+"   વેચાણ: "+money(pr)+"\nસ્ટોક કિંમત: "+money(co*q),16);
            row.setBackgroundColor(0xFFF0F5FA); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);page.addView(row,lp);
            page.addView(btn("આ વસ્તુમાં ખરીદી / વેચાણ",()->productActions(id,n)));
        } c.close(); page.addView(btn("હોમ",()->showHome()));
    }
    void productActions(int id,String name){
        new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"ખરીદી ઉમેરો","વેચાણ નોંધો"},(d,w)->transaction(id,w==0)).show();
    }
    void chooseProduct(String title,boolean purchase){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM products ORDER BY name",null);
        if(c.getCount()==0){c.close();new AlertDialog.Builder(this).setMessage("પહેલા વસ્તુ ઉમેરો.").setPositiveButton("બરાબર",null).show();return;}
        String[] names=new String[c.getCount()]; int[] ids=new int[c.getCount()];int i=0;
        while(c.moveToNext()){ids[i]=c.getInt(0);names[i]=c.getString(1);i++;} c.close();
        new AlertDialog.Builder(this).setTitle(title+" માટે વસ્તુ પસંદ કરો").setItems(names,(d,w)->transaction(ids[w],purchase)).show();
    }
    void transaction(int id,boolean purchase){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT name,cost,price,qty FROM products WHERE id="+id,null);
        if(!c.moveToFirst()){c.close();return;} String name=c.getString(0);double cost=c.getDouble(1),price=c.getDouble(2),stock=c.getDouble(3);c.close();
        LinearLayout box=new LinearLayout(this);box.setPadding(24,8,24,8);box.setOrientation(1);
        EditText qty=field("જથ્થો");qty.setInputType(8194);box.addView(qty);
        EditText unit=field(purchase?"એકમ ખરીદ કિંમત (₹)":"એકમ વેચાણ કિંમત (₹)");unit.setInputType(8194);unit.setText(String.valueOf(purchase?cost:price));box.addView(unit);
        new AlertDialog.Builder(this).setTitle((purchase?"ખરીદી: ":"વેચાણ: ")+name).setView(box)
          .setPositiveButton("સેવ",(d,w)->{try{
            double q=Double.parseDouble(qty.getText().toString()),u=Double.parseDouble(unit.getText().toString());
            if(q<=0||u<0||(!purchase&&q>stock))throw new Exception();
            db.move(id,q,u,purchase);showHome();Toast.makeText(this,"નોંધ સેવ થઈ",0).show();
          }catch(Exception e){Toast.makeText(this,purchase?"જથ્થો અને કિંમત તપાસો":"જથ્થો તપાસો; સ્ટોક કરતાં વધુ વેચાણ ન થઈ શકે",1).show();}})
          .setNegativeButton("રદ",null).show();
    }
    void showReport(){
        base("નફા અને રિપોર્ટ");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(SUM(sale_total),0),COALESCE(SUM(profit),0),COALESCE(SUM(purchase_total),0),COUNT(*) FROM movements",null);
        if(c.moveToFirst()){
            page.addView(text("કુલ વેચાણ: "+money(c.getDouble(0)),19));
            page.addView(text("વેચાણ પર કુલ નફો: "+money(c.getDouble(1)),19));
            page.addView(text("કુલ ખરીદી: "+money(c.getDouble(2)),19));
            page.addView(text("કુલ નોંધો: "+c.getInt(3),17));
        }c.close();
        page.addView(text("નોંધ: નફો વેચાણ કિંમત અને તે સમયે નોંધેલી પડતર કિંમતના તફાવતથી ગણાય છે.",13));
        page.addView(btn("હોમ",()->showHome()));
    }
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"husen_stock.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,cost REAL,price REAL,qty REAL)");
            d.execSQL("CREATE TABLE movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,kind TEXT,qty REAL,unit REAL,sale_total REAL,purchase_total REAL,profit REAL,created_at DATETIME DEFAULT CURRENT_TIMESTAMP)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void add(String n,double c,double p,double q){ContentValues v=new ContentValues();v.put("name",n);v.put("cost",c);v.put("price",p);v.put("qty",q);getWritableDatabase().insert("products",null,v);}
        void move(int id,double q,double u,boolean buy){
            SQLiteDatabase d=getWritableDatabase();Cursor c=d.rawQuery("SELECT cost,qty FROM products WHERE id="+id,null);c.moveToFirst();double oldCost=c.getDouble(0),oldQty=c.getDouble(1);c.close();
            ContentValues p=new ContentValues();p.put("qty",buy?oldQty+q:oldQty-q);if(buy)p.put("cost",u);d.update("products",p,"id=?",new String[]{String.valueOf(id)});
            ContentValues m=new ContentValues();m.put("product_id",id);m.put("kind",buy?"BUY":"SALE");m.put("qty",q);m.put("unit",u);
            m.put("sale_total",buy?0:q*u);m.put("purchase_total",buy?q*u:0);m.put("profit",buy?0:q*(u-oldCost));d.insert("movements",null,m);
        }
    }
}
